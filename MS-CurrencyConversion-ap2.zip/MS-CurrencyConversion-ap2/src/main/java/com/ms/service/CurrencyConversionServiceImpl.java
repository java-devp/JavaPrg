package com.ms.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.Builder;

import com.ms.beans.CurrencyConversionBean;
import com.ms.beans.CurrencyExchangeCostBean;

@Service
public class CurrencyConversionServiceImpl implements CurrencyConversionService {

	 private static final String CURRENCY_EXCHANGE_URL="http://localhost:7570/exchange/from/{from}/to/{to}";
	
	@Override
	public CurrencyConversionBean getCurrencyConversionVal(String from, String to, Integer value) {
		CurrencyConversionBean bean =new CurrencyConversionBean();
	     Builder builder=WebClient.builder();
	     WebClient webClient=builder.build();
	     CurrencyExchangeCostBean currencyExchangeBean=webClient.get()
	    		                 .uri(CURRENCY_EXCHANGE_URL, from,to)
	    		                 .retrieve()
	    		                 .bodyToMono(CurrencyExchangeCostBean.class)
	    		                 .block();
	     System.out.println("serviceRest::"+currencyExchangeBean);
	     double currencyCost = currencyExchangeBean.getCurrencyValue();
        double amt=currencyCost*value;
        //set to currencyConversionBean
        bean.setFrom(from);
        bean.setTo(to);
        bean.setConversionAmt(amt);
		return bean;
	}

}
