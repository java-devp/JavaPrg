package com.ms.service;

import com.ms.beans.CurrencyConversionBean;

public interface CurrencyConversionService {
    public CurrencyConversionBean getCurrencyConversionVal(String from,String to,Integer value);
}
