package com.ms.beans;

import lombok.Data;

@Data
public class CurrencyConversionBean {
   private String from;
   private String to;
  private Double conversionAmt;
	
}
