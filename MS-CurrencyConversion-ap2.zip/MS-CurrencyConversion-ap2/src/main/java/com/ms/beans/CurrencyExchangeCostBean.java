package com.ms.beans;

import lombok.Data;

@Data
public class CurrencyExchangeCostBean {
	private Integer currencyId;
	private String currencyFrom;
	private String currencyTo;
	private Double currencyValue;
}
