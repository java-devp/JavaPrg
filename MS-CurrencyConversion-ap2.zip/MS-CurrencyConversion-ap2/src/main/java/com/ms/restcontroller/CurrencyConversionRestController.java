package com.ms.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ms.beans.CurrencyConversionBean;
import com.ms.service.CurrencyConversionService;

@RestController
public class CurrencyConversionRestController {
    @Autowired
	private CurrencyConversionService service;
	
    @GetMapping(value ="/convert/from/{from}/to/{to}/value/{value}")
	public CurrencyConversionBean currencyConversionAmt(@PathVariable("from")String from,@PathVariable("to")String to,@PathVariable("value")Integer value) {
        System.out.println("from:"+from+"  to:"+to+"  value"+value);
    	CurrencyConversionBean bean=service.getCurrencyConversionVal(from, to, value);
    	return bean;
	}
}
