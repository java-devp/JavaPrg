insert into Currency_Exchange_Dtls values
(1,'USD','INR',75);

insert into Currency_Exchange_Dtls values
(2,'AUD','INR',63);

insert into Currency_Exchange_Dtls values
(3,'EUR','INR',93);