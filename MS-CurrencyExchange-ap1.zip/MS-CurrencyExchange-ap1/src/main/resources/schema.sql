create table Currency_Exchange_Dtls
(
currency_id number(10),
currency_from varchar2(10),
currency_to varchar2(10),
currency_value double(10)
);