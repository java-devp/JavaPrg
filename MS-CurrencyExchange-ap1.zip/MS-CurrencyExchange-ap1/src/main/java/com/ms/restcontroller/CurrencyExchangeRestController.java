package com.ms.restcontroller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ms.bean.CurrencyExchangeCostBean;
import com.ms.service.CurrencyExhangeService;

@RestController
public class CurrencyExchangeRestController {
    
	@Autowired
	private CurrencyExhangeService currencyService;
	
	@GetMapping(value ="/exchange/from/{from}/to/{to}",produces = "application/json")
	public CurrencyExchangeCostBean fetchExchangeVal(@PathVariable("from")String from,@PathVariable("to")String to){
		CurrencyExchangeCostBean bean=currencyService.getCurrencyExchangeVal(from, to);
		System.out.println(bean);
		return bean;
	}
	
}
