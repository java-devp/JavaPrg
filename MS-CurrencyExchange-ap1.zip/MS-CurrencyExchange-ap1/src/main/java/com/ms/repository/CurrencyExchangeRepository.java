package com.ms.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ms.entity.CurrencyExchangeEntity;

public interface CurrencyExchangeRepository extends JpaRepository<CurrencyExchangeEntity,Integer> {

	@Query(value = "select e from  CurrencyExchangeEntity e where e.currencyFrom=:from and e.currencyTo=:to")
	public CurrencyExchangeEntity getCurrencyExchangeValByFromTo(String from,String to);
}
 