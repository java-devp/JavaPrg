package com.ms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "Currency_Exchange_Dtls")
@Data
public class CurrencyExchangeEntity {
	@Id
	@Column(name = "Currency_Id")
	private Integer currencyId;
	@Column(name = "Currency_From")
	private String currencyFrom;
	@Column(name = "Currency_To")
	private String currencyTo;
	@Column(name = "Currency_Value")
	private double currencyValue;
}
