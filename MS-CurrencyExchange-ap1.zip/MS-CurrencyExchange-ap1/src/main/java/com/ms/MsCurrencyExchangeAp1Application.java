package com.ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsCurrencyExchangeAp1Application {

	public static void main(String[] args) {
		SpringApplication.run(MsCurrencyExchangeAp1Application.class, args);
	}

}
