package com.ms.service;

import com.ms.bean.CurrencyExchangeCostBean;

public interface CurrencyExhangeService {
	public CurrencyExchangeCostBean getCurrencyExchangeVal(String from,String to);
}
