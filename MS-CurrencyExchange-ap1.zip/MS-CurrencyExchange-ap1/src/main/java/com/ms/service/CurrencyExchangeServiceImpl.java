package com.ms.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.bean.CurrencyExchangeCostBean;
import com.ms.entity.CurrencyExchangeEntity;
import com.ms.repository.CurrencyExchangeRepository;

@Service
public class CurrencyExchangeServiceImpl implements CurrencyExhangeService {
    @Autowired
	private CurrencyExchangeRepository currencyExchRepo;

	@Override
	public CurrencyExchangeCostBean getCurrencyExchangeVal(String from, String to) {
		System.out.println("service=="+"from"+from+"  to"+to);
		CurrencyExchangeCostBean bean=new CurrencyExchangeCostBean();
		CurrencyExchangeEntity entity=currencyExchRepo.getCurrencyExchangeValByFromTo(from, to);
		System.out.println("service:"+entity);
		BeanUtils.copyProperties(entity, bean);
		return bean;
	}
	
    
}
